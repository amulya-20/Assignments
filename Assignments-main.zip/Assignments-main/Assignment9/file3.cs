using System;

class UserName 
{
    static void Main(string[] args) 
    {
        Console.Write("What is your name? ");
        string name = Console.ReadLine();
        Console.WriteLine("Hello, " + name + "!");
        Console.WriteLine("BYE");

    }
}
